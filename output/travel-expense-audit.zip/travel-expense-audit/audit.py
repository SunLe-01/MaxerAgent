# -*- coding: utf-8 -*-
"""可选辅助脚本：差旅报销单审核
用法: python audit.py '{"city":"成都","level":"P4-P5","nights":2,"hotel_price":650,"days":3}'
"""
import json
import sys

TIER1 = {"北京", "上海", "广州", "深圳"}
TIER2 = {"杭州", "成都", "南京", "武汉", "西安", "苏州", "天津", "重庆", "长沙", "郑州",
         "青岛", "宁波", "厦门", "合肥", "济南", "福州", "东莞", "佛山"}
LODGING = {"P1-P3": [600, 450, 350], "P4-P5": [700, 550, 450],
           "M1-M2": [900, 700, 600], "M3+": [1200, 1000, 800]}
MEAL = [100, 80, 60]


def main(data: dict) -> dict:
    city = data.get("city", "")
    idx = 0 if city in TIER1 else (1 if city in TIER2 else 2)
    tier = ["一类", "二类", "三类"][idx]
    level = data.get("level", "").upper()
    if level not in LODGING:
        return {"error": "职级不支持，请用 P1-P3 / P4-P5 / M1-M2 / M3+"}
    cap = LODGING[level][idx]
    nights = int(data.get("nights", 0))
    price = float(data.get("hotel_price", 0))
    days = int(data.get("days", 0))
    over = max(price - cap, 0) * nights
    meal = (MEAL[idx] // 2 if nights == 0 else MEAL[idx]) * days
    return {
        "city_tier": tier,
        "lodging_cap_per_night": cap,
        "lodging_over_total": round(over, 2),
        "meal_total": meal,
        "reimbursable_total": round(min(price * nights, cap * nights) + meal, 2),
    }


if __name__ == "__main__":
    payload = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    print(json.dumps(main(payload), ensure_ascii=False, indent=2))
